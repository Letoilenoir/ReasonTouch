package com.reasontouch.feature.pianoroll

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reasontouch.core.data.ChordEvent
import com.reasontouch.core.data.MidiTrack
import com.reasontouch.core.data.NoteEvent
import com.reasontouch.core.data.Session
import com.reasontouch.core.data.SessionRepository
import com.reasontouch.core.audio.SynthEngine
import com.reasontouch.core.audio.SynthVoice
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class PianoRollViewModel @Inject constructor(
    private val repository: SessionRepository,
    private val synthEngine: SynthEngine,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val sessionId: String = checkNotNull(savedStateHandle["sessionId"])

    // ── Session ───────────────────────────────────────────────────────────
    val session: StateFlow<Session?> = repository.getSession(sessionId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // ── Tracks ────────────────────────────────────────────────────────────
    val tracks: StateFlow<List<MidiTrack>> = repository.getTracksForSession(sessionId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ── Chord progression (read-only, shown as ghost lane) ────────────────
    val chords: StateFlow<List<ChordEvent>> = repository.getChordsForSession(sessionId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ── Active track ──────────────────────────────────────────────────────
    private val _activeTrackIndex = MutableStateFlow(0)
    val activeTrackIndex: StateFlow<Int> = _activeTrackIndex.asStateFlow()

    // ── Notes per track (cached for active track) ─────────────────────────
    private val _activeNotes = MutableStateFlow<List<NoteEvent>>(emptyList())
    val activeNotes: StateFlow<List<NoteEvent>> = _activeNotes.asStateFlow()

    // ── All notes for ghost rendering ─────────────────────────────────────
    private val _allNotes = MutableStateFlow<Map<String, List<NoteEvent>>>(emptyMap())
    val allNotes: StateFlow<Map<String, List<NoteEvent>>> = _allNotes.asStateFlow()

    // ── Playback ──────────────────────────────────────────────────────────
    private var playbackJob: kotlinx.coroutines.Job? = null

    fun play(bpm: Int) {
        if (_isPlaying.value) return
        _isPlaying.value = true
        val startBeat    = _playheadBeat.value
        val beatDurMs    = 60000.0 / bpm.toDouble()
        val startTime    = System.currentTimeMillis()
        val endBeat      = if (_loopEnabled.value) _loopEnd.value else 16f
        val allNotesList = _allNotes.value

        playbackJob = viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
            // Schedule note audio on IO
            tracks.value.forEach { track ->
                if (track.muted) return@forEach
                val notes = allNotesList[track.id] ?: emptyList()
                val voice = com.reasontouch.core.audio.SynthVoice.fromString(track.voice)
                notes.filter { it.beat >= startBeat }.forEach { note ->
                    val delayMs = ((note.beat - startBeat) * beatDurMs).toLong()
                    val durSec  = (note.duration * beatDurMs / 1000.0).toFloat()
                    launch(kotlinx.coroutines.Dispatchers.IO) {
                        kotlinx.coroutines.delay(delayMs)
                        if (_isPlaying.value) {
                            val midi = (108 - note.pitch).coerceIn(0, 127)
                            synthEngine.playNote(midi, durSec, note.velocity, voice)
                        }
                    }
                }
            }

            // Playhead update loop — runs on Main for StateFlow updates
            while (_isPlaying.value) {
                val elapsed     = System.currentTimeMillis() - startTime
                val currentBeat = startBeat + (elapsed / beatDurMs).toFloat()
                when {
                    currentBeat >= endBeat && _loopEnabled.value -> {
                        _playheadBeat.value = _loopStart.value
                    }
                    currentBeat >= endBeat -> {
                        _playheadBeat.value = endBeat
                        _isPlaying.value = false
                        break
                    }
                    else -> _playheadBeat.value = currentBeat
                }
                kotlinx.coroutines.delay(16)
            }
        }
    }

    fun stop() {
        playbackJob?.cancel()
        playbackJob = null
        _isPlaying.value = false
    }

    fun rewind() {
        stop()
        _playheadBeat.value = 0f
    }

    fun bounceDown(sourceIndices: List<Int>, destIndex: Int, clearSources: Boolean) {
        viewModelScope.launch {
            val trackList = tracks.value
            val destTrack = trackList.getOrNull(destIndex) ?: return@launch
            val mergedNotes = sourceIndices.flatMap { i ->
                val track = trackList.getOrNull(i) ?: return@flatMap emptyList()
                (_allNotes.value[track.id] ?: emptyList()).map {
                    it.copy(id = UUID.randomUUID().toString(), trackId = destTrack.id)
                }
            }
            repository.saveNotes(mergedNotes)
            if (clearSources) {
                sourceIndices.forEach { i ->
                    val track = trackList.getOrNull(i) ?: return@forEach
                    if (i != destIndex) repository.deleteNotesForTrack(track.id)
                }
            }
            loadTracksAndNotes()
        }
    }
}